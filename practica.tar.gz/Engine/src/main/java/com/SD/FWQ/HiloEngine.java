import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;


import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class HiloEngine extends Thread
{
    private HashMap<Character,Integer> tiempoatracciones;
    private HashMap<Character,Tuple<Integer,Integer>> atraccionesposi,visitantesposi;
    private final Consumer<Long, String> consumidor;
    private final Producer<Long, String> productor;
    private String mapa,lista;
    private final int tamanomapa;
    private boolean waitingup;

    public HiloEngine(int tamanomapa, Consumer<Long, String> consumidor, Producer<Long,String> productor)
    {
		tiempoatracciones = new HashMap<>();
		atraccionesposi = new HashMap<>();
        visitantesposi = new HashMap<>();
        CargarMapa();   //Cargo datos de atracciones
        mapa = ConstruyeMapa(); // Construyo el mapa con las atracciones
        this.tamanomapa = tamanomapa;
        this.consumidor = consumidor;
        this.productor = productor;

        //this.waitingup = waitingup;

    }
    public void run()
    {
        try
        {

            runConsumer();

        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        finally
        {
			consumidor.close();
			System.out.println("DONE");
		}
			
    }
    private void runConsumer() throws InterruptedException
    {
        final Consumer<Long, String> consumer = consumidor;

        final int giveUp = 100;   int noRecordsCount = 0;

        while (true)
        {
			//visitantesposi = new HashMap<>();
            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(3000);
			
			String returned = "";
            
            if (consumerRecords.count()==0)	//Mapa con 0 visitantes
            {
					//tiempoatracciones = ProcesaTiempos(returned);
					lista = ConstruyeLista();
					mapa = ConstruyeMapa();
					StringBuilder sb = new StringBuilder();
					sb.append(mapa);
					sb.append('_');
					sb.append(lista);
					System.out.println(sb.toString());
					ProducerRecord producerRecord = new ProducerRecord<Long,String>("mapa",sb.toString());    //Enviamos el MAPA+LISTA
					productor.send(producerRecord);
                /*noRecordsCount++;
				if (noRecordsCount > giveUp)
                    break;
                else
                    continue;*/
            } 
				for(ConsumerRecord record : consumerRecords)
				{
					//tiempoatracciones = ProcesaTiempos(returned);
					lista = ConstruyeLista();
					String recepcion = record.value().toString();
					ProcesaVisitante(recepcion);
					mapa = ConstruyeMapa();
					StringBuilder sb = new StringBuilder();
					sb.append(mapa);
					sb.append('_');
					sb.append(lista);
					ProducerRecord producerRecord = new ProducerRecord<Long,String>("mapa",sb.toString());    //Enviamos el MAPA+LISTA
					productor.send(producerRecord);
				}

            consumer.commitSync();
        }
    }

    private String ConstruyeMapa()  // Crea un Mapa con las atracciones y los visitantes que haya
    {

        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < tamanomapa ; i++)
        {
            for(int j = 0; j < tamanomapa ; j++)
            {
				boolean puesto = false;
				if(visitantesposi != null)	// Coloco visitantes
				{
					
					for(Map.Entry<Character,Tuple<Integer,Integer>> set : visitantesposi.entrySet())
						if(set.getValue().x == i && set.getValue().y == j)
						{
							sb.append(set.getKey());
							puesto = true;
						}
						if(!puesto)
							sb.append('.');
				}
				if(atraccionesposi != null)	//Coloco Atracciones
				{
					for(Map.Entry<Character,Tuple<Integer,Integer>> set : atraccionesposi.entrySet())
						if(set.getValue().x == i && set.getValue().y == j)
						{
							sb.append(set.getKey());
							puesto = true;
						}
						if(!puesto)
							sb.append('.');
				}
				else
					sb.append('.');
			}
            sb.append('\n');
        }

        return sb.toString();
    }
    private String ConstruyeLista()
    {
        StringBuilder sb = new StringBuilder();
        for(Map.Entry<Character,Integer> set : tiempoatracciones.entrySet())   // Recorro todas las atracciones
        {
            sb.append(set.getKey()); //Añado el ID
            sb.append(':');
            sb.append(set.getValue()); // Añado el tiempo
            sb.append(',');
            Tuple<Integer,Integer> posicion = atraccionesposi.get(set.getKey());
            sb.append(posicion.x); // Añado la x
            sb.append('.');
            sb.append(posicion.y);  // Añado la y
            sb.append('-');
        }
        return sb.toString();
    }
    public void ActualizaTiempos(String tiempos)
    {
		//Recibimos la lista con el FORMATO-> ID1:TIEMPO1,ID2:TIEMPO2
		//lista = tiempos;
		String[] atrtiempos = tiempos.split(",");
		for(String tiempo : atrtiempos)
		{
			String[] division = tiempo.split(":");
			tiempoatracciones.put(division[0].charAt(0),Integer.parseInt(division[1]));
		}
	}
    public HashMap<Character,Integer> ProcesaTiempos(String procesar)  // Devuelve un hashmap con el id de la atracción y su tiempo
    {
        char id = '\0';
        HashMap<Character,Integer> procesado = new HashMap<>();

        for (int i = 0; i < procesar.length(); i++)
        {
            StringBuilder numero = new StringBuilder();
            id = procesar.charAt(i);
            i++;
            while (i < procesar.length() && procesar.charAt(i) != ',' )   // Cojo todos los números del tiempo
            {
                if (procesar.charAt(i) != ':')
                    numero.append(procesar.charAt(i));
                i++;
            }
            int truenumero = Integer.parseInt(numero.toString());   // Transformo el número en int
            procesado.put(id,truenumero);
        }
        return procesado;
    }
    private void ProcesaVisitante(String procesar)  // Modifica / Crea el visitante con la posición en el HashMap
    {
		System.out.println("Visitante: "+procesar);
        Tuple<Integer,Integer> posicion = new Tuple<>();
        char id = procesar.charAt(0);
        for (int i = 2; i < procesar.length(); i++)
        {
            StringBuilder numero = new StringBuilder();
            while (procesar.charAt(i) != '.' )   // Cojo todos los números de la 1era coordenada
            {
                numero.append(procesar.charAt(i));
                i++;
            }
            i++;
            int truenumero = Integer.parseInt(numero.toString());   // Transformo el número en int
            posicion.x = truenumero;
            numero = new StringBuilder();
            while (i < procesar.length() && procesar.charAt(i) != '.' )   // Cojo todos los números de la 2a coordenada
            {
                numero.append(procesar.charAt(i));
                i++;
            }
            truenumero = Integer.parseInt(numero.toString());   // Transformo el número en int
            posicion.y = truenumero;
        }
		if (posicion.x == 69 && posicion.y == 69)
			visitantesposi.remove(id);
		else
			visitantesposi.put(id,posicion);    // Añado el visitante junto a su posición al Hashmap

    }
    private void CargarMapa() // Carga desde la BDD los datos de atracciones
    {
        String sql = "Select * from mapa";

        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql))
        {
            Class.forName("org.sqlite.JDBC");
            while(rs.next())
            {
                if(rs.getString("id_atracciones") != null)  // Si hay una atracción
                {
                    Tuple<Integer,Integer> coords = new Tuple<>();
                    coords.x = rs.getInt("Fila");
                    coords.y = rs.getInt(("Columna"));
                    atraccionesposi.put(rs.getString("id_atracciones").charAt(0),coords);
                }
            }
        }
        catch(SQLException e)
        {
            System.out.println(e.getMessage());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }
    private static Connection connect()
    {
       
		Connection connection = null;
		try
		{
		  Class.forName("org.sqlite.JDBC");
		  
		  // create a database connection
		  connection = DriverManager.getConnection("jdbc:sqlite:BDD.db");
		  Statement statement = connection.createStatement();
		  statement.setQueryTimeout(10);  // set timeout to 10 sec.
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return connection;
	}
    
}
