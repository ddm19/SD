import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import org.json.JSONObject;
import org.xml.sax.SAXException;

import java.awt.*;    
import javax.swing.*;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.Collectors;

public class HiloVisitor extends Thread
{
    private final String id;
    private final Consumer<Long,String> consumidor;
    private final Producer<Long,String> productor;
    private Tuple<Integer,Integer> posicion;
    private String recepcion;
    private final HashMap<Character,Integer> atraccionestiempo;
    private final HashMap<Character,Tuple<Integer,Integer>> atraccionesposi;
    private char atracciondestino;
    private float zonas[];
    private JFrame f;


    public HiloVisitor(Consumer<Long, String> consumidor, Producer<Long,String>productor, String id, int x, int y)
    {
        this.consumidor = consumidor;
        this.productor = productor;
        this.id = id;
        this.posicion = new Tuple<>();
        atraccionestiempo = new HashMap<>();
        atraccionesposi = new HashMap<>();
        this.posicion.x = x;
        this.posicion.y = y;
        this.atracciondestino = '\0';
        zonas = new float[5];
        for(int i = 1 ; i < zonas.length ;i++ )
            zonas[i] = ObtieneClima(ObtieneCiudad(i));
        f = new JFrame();

    }

    public void run()
    {
		Runtime.getRuntime().addShutdownHook(new Thread() {
		public void run() {
		    System.out.println("Saliendo del parque...");						//Detectar Ctrl+C
		    posicion.x = 69;
		    posicion.y = 69;
		    Mover(0,0);
		    
		}
	    });
	    
        try
        {
            runConsumer();

        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        finally
        {
			consumidor.close();
			System.out.println("DONE");
		}
    }
    private void runConsumer() throws InterruptedException
    {
		final Consumer<Long, String> consumer = consumidor;

        final int giveUp = 100;   int noRecordsCount = 0;

        while (true)
        {
			final ConsumerRecords<Long, String> consumerRecords = consumer.poll(3000);

            if (consumerRecords.count() == 0) {
                noRecordsCount++;
                if (noRecordsCount > giveUp)
                    break;
                else
                    continue;
            }

            for (ConsumerRecord record : consumerRecords)
            {
				//System.out.println(record.value().toString());  
                recepcion = record.value().toString();
            }
            if(recepcion != null)
			{
				//System.out.println(recepcion);
				runner();   // Imprimo mapa y comienzo movimiento
			}
            consumer.commitSync();
            try
			{
				sleep(2000);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
        }
        
        

        
    }
    private void runner()
    {
        String analisis = recepcion;
        String[] divisor = analisis.split("_");
		if(divisor.length == 2)
		{
			System.out.print("\033[H\033[2J");
			System.out.flush();
			ProcesarLista(divisor[1]);
			ImprimeMapa(divisor[0]);

			runMovement();
		}

    }
    private void runMovement()
    {
        if(atracciondestino == '\0')  // Todavía no hemos escogido atracción
        {
            EscogeAtraccion();
        }
        else if(atraccionestiempo.get(atracciondestino) > 60) // El tiempo de la atracción ha cambiado a > 60
        {
            EscogeAtraccion();
        }
        else
        {
            // Movimiento hacia atracción
            Tuple<Integer,Integer> posiciondestino = atraccionesposi.get(atracciondestino);

            if(posicion.y < posiciondestino.y)  // Movimiento Norte
            {
                if(posicion.x < posiciondestino.x) //  Noreste
                    Mover(1,1);
                else if(posicion.x > posiciondestino.x) //  Noroeste
                    Mover(-1,1);
                else                                    // Ya estamos en x, Norte
                    Mover(0,1);
            }
            else if (posicion.y > posiciondestino.y) // Movimiento Sur
            {
                if(posicion.x < posiciondestino.x) //  Sureste
                    Mover(1,-1);
                else if(posicion.x > posiciondestino.x) //  Suroeste
                    Mover(-1,-1);
                else                                    // Ya estamos en x, Sur
                    Mover(0,-1);
            }
            else if (posicion.y == posiciondestino.y && posicion.x != posiciondestino.x)
            {
				if(posicion.x < posiciondestino.x) //  Este
                    Mover(1,0);
                else if(posicion.x > posiciondestino.x) //  Oeste
                    Mover(-1,0);
			}
            else    // Estamos en x,y hemos llegado
            {
                

                try
                {
					System.out.println("Llego a la atracción: " + atracciondestino + "Haciendo cola y montando durante: " + (atraccionestiempo.get(atracciondestino)+(posiciondestino.y + 4)) + " Segundos.");
					sleep((atraccionestiempo.get(atracciondestino))*1000);	// Esperamos la cola de la atracción
                    sleep((posiciondestino.y + 4)*1000);   // Esperamos el tiempo de la atracción (su coordenada y + 4 segundos)
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                // Reset de la atracción escogida
                atracciondestino = '\0';
            }
		}
		
    }
    private void Mover(int x, int y)
    {
        posicion.x += x;
        posicion.y += y;
        String valor = id+"-"+posicion.x+"."+posicion.y;
        ProducerRecord producerRecord = new ProducerRecord<Long,String>("posiciones",valor);    //Enviamos la posición nueva a Engine
        productor.send(producerRecord);
    }
    private void EscogeAtraccion()
    {
		char[] ids = new char[atraccionestiempo.size()];
		int i = 0;
		for(Map.Entry<Character,Integer> set : atraccionestiempo.entrySet())	// Recorro las atracciones
		{
			if(set.getValue() < 60)	// Guardo las q tienen menor tiempo que 60
			{
				ids[i] = set.getKey();
				i++;
			}
		}

        Random generator = new Random();
        atracciondestino = ids[generator.nextInt(ids.length)];        // Selecciono una atracción


    }
    private void ProcesarLista(String procesar) // Formato lista ID:TIEMPO,XX.YY-ID2:TIEMPO2,XX.YY
    {
        int truenumero = -1;
        char id;

        for(int i = 0; i < procesar.length() ; i++)
        {
            int x = 0,y = 0;
            StringBuilder numero = new StringBuilder();
            id = procesar.charAt(i);
            i++;
            while(procesar.charAt(i) != ',')   // Cojo todos los números del tiempo
            {
                if(procesar.charAt(i) != ':')
                    numero.append(procesar.charAt(i));
                i++;
            }
            i++;
            try
            {
                x = Character.getNumericValue(procesar.charAt(i));
                i++;
                if(procesar.charAt(i) != '.')
                {
                    x = x*10;
                    x += Character.getNumericValue(procesar.charAt(i));
                    i++;
                }
                i++;
                y = Character.getNumericValue(procesar.charAt(i));
                i++;
                if(i != procesar.length() && procesar.charAt(i) != '-')
                {
                    y = y*10;
                    y += Character.getNumericValue(procesar.charAt(i));
                    i++;
                }


                truenumero = Integer.parseInt(numero.toString());   // Transformo el número en int
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            Tuple coords = new Tuple<Integer,Integer>();
            coords.x = x;
            coords.y = y;
            atraccionestiempo.put(id,truenumero);  // Añado el par ID-TIEMPO al hashmap
            atraccionesposi.put(id,coords);        // Añado el par ID-POSICION al hashmap
        }

    }

    private static int getZona(int x, int y, int tam)
    {
        int zona = -1;

        if( y < tam/2 )
            if(x < tam/2)
                zona = 1;
            else
                zona = 3;
        else
        if(x < tam/2)
            zona = 2;
        else
            zona = 4;

        return zona;
    }

    private static String ObtieneAPIKEY()
    {
        String clave = "";

        try
        {
            File myObj = new File("APIKEY.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                clave = data;
            }
            myReader.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        return clave;
    }
    private static String LeeArchivo(String archivo,int dato)
    {
        String clave = "";
        try
        {
            File myObj = new File(archivo);
            Scanner myReader = new Scanner(myObj);
            int i = 0;
            while (myReader.hasNextLine() && i < dato)
            {
                String data = myReader.nextLine();
                clave = data;
                i++;
            }
            myReader.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        return clave;
    }
    public static JSONObject http(String ciudad,String apikey) throws IOException, ParserConfigurationException, SAXException, XPathExpressionException
    {
        OkHttpClient client = new OkHttpClient();
        String url = "https://community-open-weather-map.p.rapidapi.com/weather?q="+ciudad+"%2Ces&lat=0&lon=0&id=2172797&lang=null&units=metric&mode=JSON";
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("x-rapidapi-host", "community-open-weather-map.p.rapidapi.com")
                .addHeader("x-rapidapi-key", apikey)
                .build();

        ResponseBody response = client.newCall(request).execute().body();
        String json = response.string();
        //System.out.println(json+"\n");

        JSONObject obj = new JSONObject(json);

        return obj;


        /*JSONArray arr = obj.getJSONArray("main");

        for (int i = 0; i < arr.length(); i++)
        {
            String post_id = arr.getJSONObject(i).getString("temp");
            System.out.println(post_id);
        }*/
    }
    private static float ObtieneClima(String ciudad)   // Devuelve el JSON con el clima
    {

        float temp = -1;

        String apikey = LeeArchivo("APIKEY.txt",1);

        System.out.println(ciudad);

        try
        {
            JSONObject obj = http(ciudad,apikey);
            //System.out.println(obj);
            float pageName = obj.getJSONObject("main").getFloat("temp");
            temp = pageName;
            System.out.println(pageName);
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
        return temp;
    }

    private static String ObtieneCiudad(int zona)
    {
        String ciudad = "";

        int i = 0;

        try
        {
            File myObj = new File("ciudades.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine() && i < zona)
            {

                String data = myReader.nextLine();
                ciudad = data;
                i++;
            }
            myReader.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // System.out.println(ciudad);

        return ciudad;
    }
    private void ImprimeMapa(String procesar)
    {
		f.getContentPane().removeAll();
		f.repaint();

        for(int i = 0; i < procesar.length() ; i++)
        {
			JPanel panel = new JPanel();
			int tam = (int) Math.sqrt(procesar.length());
            if (procesar.charAt(i) == '.' || procesar.charAt(i) == '\n')      // Carácter vacío de Mapa
            {

                int x = i / tam;
                int y = i % tam;
                int zona = getZona(x,y,tam);
                if(zonas[zona] < 20 )
                    panel.setBackground(Color.lightGray);
                else if (zonas[zona] > 30)
                    panel.setBackground(Color.red);
                else
                    switch (getZona(x, y, tam))
                    {
                        case 1:
                            panel.setBackground(Color.yellow);
                            break;
                        case 2:
                            panel.setBackground(Color.orange);
                            break;
                        case 3:
                            panel.setBackground(Color.pink);
                            break;
                        case 4:
                            panel.setBackground(Color.green);
                            break;
                    }
            }
                //System.out.print('.');
            else if (Character.isLetter(procesar.charAt(i)))
            {
				panel.setBackground(new Color(0,0,255,80));
				panel.add(new JLabel(Character.toString(procesar.charAt(i))));
			}
                //System.out.print(procesar.charAt(i));    // ID visitante mapa
            else if (Character.isDigit(procesar.charAt(i)))
            {
				panel.setBackground(new Color(255,255,0,80));
				panel.add(new JLabel(atraccionestiempo.get(procesar.charAt(i)).toString()));
			}
                //System.out.print(atraccionestiempo.get(procesar.charAt(i)));  // Recupero el tiempo y lo imprimo


                //System.out.println();                                   // Salto de línea

           f.add(panel);
        }

        f.setLayout(new GridLayout(20,20));
		f.setSize(600,600);
        f.pack();
		f.setVisible(true);
    }
}
